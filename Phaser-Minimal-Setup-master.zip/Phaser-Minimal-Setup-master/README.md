# Phaser-Minimal-Setup
Minimal setup for Phaser 2D HTML5 games
