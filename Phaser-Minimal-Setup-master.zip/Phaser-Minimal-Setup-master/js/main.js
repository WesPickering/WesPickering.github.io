var game = new Phaser.Game(1080, 720, Phaser.AUTO, '', { preload: preload, create: create, update: update });

function preload() {
}

function create() {
}

function update() {
}

function createPlayer(x,y){
}

function playerUpdate(){
}

function createPlatform(){
}
